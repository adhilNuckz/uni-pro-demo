import React from 'react';
import { Globe, Shield, Code, Server, Calendar, FolderOpen } from 'lucide-react';
import { Site } from './Sites';

interface SiteDetailsProps {
  site: Site;
  onSiteUpdate: (site: Site) => void;
}

export default function SiteDetails({ site, onSiteUpdate }: SiteDetailsProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center mb-6">
        <Globe className="w-6 h-6 text-blue-500 mr-3" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          {site.domain}
        </h3>
      </div>

      <div className="space-y-4">
        <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Status
            </span>
            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
              site.status === 'online'
                ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400'
                : site.status === 'offline'
                ? 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
                : 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400'
            }`}>
              {site.status}
            </span>
          </div>
          
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-300">
              SSL Certificate
            </span>
            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
              site.ssl
                ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400'
                : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
            }`}>
              {site.ssl ? 'Enabled' : 'Disabled'}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-300">
              Daily Visitors
            </span>
            <span className="text-sm font-bold text-gray-900 dark:text-white">
              {site.visitors}
            </span>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center">
            <FolderOpen className="w-4 h-4 text-gray-400 mr-3" />
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                Document Root
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {site.path}
              </p>
            </div>
          </div>

          <div className="flex items-center">
            <Code className="w-4 h-4 text-gray-400 mr-3" />
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                PHP Version
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {site.phpVersion}
              </p>
            </div>
          </div>

          <div className="flex items-center">
            <Calendar className="w-4 h-4 text-gray-400 mr-3" />
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                Created
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {new Date(site.created).toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">
            Quick Actions
          </h4>
          <div className="space-y-2">
            <button className="w-full text-left px-3 py-2 text-sm bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors">
              Configure DNS
            </button>
            <button className="w-full text-left px-3 py-2 text-sm bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/50 transition-colors">
              Create Backup
            </button>
            <button className="w-full text-left px-3 py-2 text-sm bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/50 transition-colors">
              View Analytics
            </button>
            <button className="w-full text-left px-3 py-2 text-sm bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors">
              Delete Site
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}